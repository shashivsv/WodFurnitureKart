---
title: "Material Dashboard Pro"
affiliate: "Creative Tim"
slug: material-dashboard-pro
date: 2018-01-06
src: https://www.creative-tim.com/product/material-dashboard-pro/?affiliate_id=101249
categories: creative-tim mix admin
bump: "Premium Bootstrap Admin Template"
img-thumbnail: /assets/img/screenshots/premium/creative-tim/mdp.jpg
img-desc: "Material Dashboard Pro - Premium Bootstrap Admin Template"
---

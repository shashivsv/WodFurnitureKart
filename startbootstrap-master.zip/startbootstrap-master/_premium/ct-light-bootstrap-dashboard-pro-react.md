---
title: "Light Bootstrap Dashboard Pro React"
affiliate: "Creative Tim"
slug: lbd-pro-react
date: 2018-01-01
src: https://www.creative-tim.com/product/light-bootstrap-dashboard-pro-react/?affiliate_id=101249
categories: creative-tim mix admin
bump: "Premium Bootstrap React Admin Template"
img-thumbnail: /assets/img/screenshots/premium/creative-tim/lbdp-react.jpg
img-desc: "Light Bootstrap Dashboard Pro React - Premium Bootstrap React Admin Template"
---

---
title: "Vue Material Dashboard Pro"
affiliate: "Creative Tim"
slug: vue-md-pro
date: 2018-01-03
src: https://www.creative-tim.com/product/vue-material-dashboard-pro/?affiliate_id=101249
categories: creative-tim admin
bump: "Premium Bootstrap Vue Template"
img-thumbnail: /assets/img/screenshots/premium/creative-tim/mdp-vue.jpg
img-desc: "Vue Material Dashboard Pro - Premium Bootstrap Vue.js Theme"
---

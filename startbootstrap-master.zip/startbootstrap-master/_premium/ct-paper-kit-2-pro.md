---
title: "Paper Kit 2 Pro"
affiliate: "Creative Tim"
slug: paper-kit-2
date: 2018-01-02
src: https://www.creative-tim.com/product/paper-kit-2-pro/?affiliate_id=101249
categories: creative-tim ui
bump: "Premium Bootstrap 4 UI Kit"
img-thumbnail: /assets/img/screenshots/premium/creative-tim/pk2p.jpg
img-desc: "Paper Kit 2 Pro - Premium Bootstrap 4 UI Kit"
---

---
title: "Material Dashboard Pro Angular"
affiliate: "Creative Tim"
slug: mdp-angular
date: 2018-01-08
src: https://www.creative-tim.com/product/material-dashboard-pro-angular2/?affiliate_id=101249
categories: creative-tim mix admin
bump: "Premium Bootstrap Angular Template"
img-thumbnail: /assets/img/screenshots/premium/creative-tim/mdp-angular.jpg
img-desc: "Material Dashboard Pro Angular 2 - Premium Bootstrap Angular Template"
---

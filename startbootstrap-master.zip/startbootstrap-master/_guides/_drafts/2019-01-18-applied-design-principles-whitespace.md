---
title:            "Applied Design Principles: Working with Whitespace"
description:	    "Applied examples of how whitespace can improve a page's design quality"

date:             2019-01-18

src:               /guides/applied-design-principles-whitespace

categories:
  - new
  - design

layout:		    	  page
type:             theme

meta-title:        "Applied Design Principles: Working with Whitespace"
meta-description:  "Applied examples of how whitespace can improve a page's design quality"
---

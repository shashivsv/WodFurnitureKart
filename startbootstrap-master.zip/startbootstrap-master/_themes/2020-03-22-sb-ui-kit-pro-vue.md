---
title:            "SB UI Kit Pro Vue"
slug:             sb-ui-kit-pro-vue
src:              https://shop.startbootstrap.com/product/sb-ui-kit-pro-vue/
categories:       landing-page business portfolio-resume blog
bump:             "A premium Vue.js UI Kit"
img-thumbnail:    /assets/img/screenshots/premium/sb-ui-kit-pro-vue.jpg
img-full:         /assets/img/screenshots/premium/sb-ui-kit-pro-vue.png
img-desc:         "Premium Vue.js UI Kit - SB UI Kit Pro Vue"
layout:           custom-redirect
type:             theme
pro:              true
new:              true
rank: 9
---

---
title:            "SB UI Kit Pro Angular"
slug:             sb-ui-kit-pro-angular
src:              https://shop.startbootstrap.com/product/sb-ui-kit-pro-angular/
categories:       landing-page business portfolio-resume blog
bump:             "A premium Angular 9 UI Kit"
img-thumbnail:    /assets/img/screenshots/premium/sb-ui-kit-pro-angular.jpg
img-full:         /assets/img/screenshots/premium/sb-ui-kit-pro-angular.png
img-desc:         "Premium Angular 9 UI Kit - SB UI Kit Pro"
layout:           custom-redirect
type:             theme
pro:              true
new:              true
rank: 3
---

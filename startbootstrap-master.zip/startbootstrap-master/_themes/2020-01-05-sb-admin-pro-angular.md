---
title:            "SB Admin Pro Angular"
slug:             sb-admin-pro-angular
src:              https://themes.startbootstrap.com/sb-admin-pro-angular/
categories:       admin
bump:             "A premium Angular 9 admin template"
img-thumbnail:    /assets/img/screenshots/premium/sb-admin-pro-angular.jpg
img-full:         /assets/img/screenshots/premium/sb-admin-pro-angular.png
img-desc:         "Bootstrap Angular 9 Admin Theme - SB Admin Pro Angular"
layout:           custom-redirect
type:             theme
pro:              true
new:              true
rank: 4
---

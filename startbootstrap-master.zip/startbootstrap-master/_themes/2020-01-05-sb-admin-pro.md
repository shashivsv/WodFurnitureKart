---
title:            "SB Admin Pro"
slug:             sb-admin-pro
src:              https://shop.startbootstrap.com/product/sb-admin-pro/
categories:       admin
bump:             "A premium Bootstrap admin theme"
img-thumbnail:    /assets/img/screenshots/premium/sb-admin-pro-html.jpg
img-full:         /assets/img/screenshots/premium/sb-admin-pro-html.png
img-desc:         "Premium Bootstrap 4 Admin Theme - SB Admin Pro"
layout:           custom-redirect
type:             theme
pro:              true
new:              true
update:           true
rank: 2
---

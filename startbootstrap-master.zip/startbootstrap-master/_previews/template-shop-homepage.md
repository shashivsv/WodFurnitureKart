---
title:            "Shop Homepage"
slug:             shop-homepage
category:         templates
src:              /templates/shop-homepage
layout:           preview
type:             template
meta-title:       Shop Homepage - Template Preview
migrated:         true
---

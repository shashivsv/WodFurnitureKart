---
title:            "SB Admin 2"
slug:             sb-admin-2
category:         themes
src:              /themes/sb-admin-2
layout:           preview
type:             theme
meta-title:       SB Admin 2 - Theme Preview
migrated:         true
---

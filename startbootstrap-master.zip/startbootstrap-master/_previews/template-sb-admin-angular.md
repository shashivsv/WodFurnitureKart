---
title:            "SB Admin Angular"
slug:             sb-admin-angular
category:         templates
src:              /templates/sb-admin-angular
layout:           preview
type:             template
meta-title:       SB Admin Angular - Template Preview

custom-preview-link: "https://sb-admin-angular.startbootstrap.com"
no-prefix: true
---

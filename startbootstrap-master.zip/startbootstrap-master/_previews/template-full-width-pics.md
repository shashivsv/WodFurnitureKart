---
title:            "Full Width Pics"
slug:             full-width-pics
category:         templates
src:              /templates/full-width-pics
layout:           preview
type:             template
meta-title:       Full Width Pics - Template Preview
migrated:         true
---

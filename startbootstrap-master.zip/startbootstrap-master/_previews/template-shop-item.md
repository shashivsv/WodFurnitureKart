---
title:            "Shop Item"
slug:             shop-item
category:         templates
src:              /templates/shop-item
layout:           preview
type:             template
meta-title:       Shop Item - Template Preview
migrated:         true
---

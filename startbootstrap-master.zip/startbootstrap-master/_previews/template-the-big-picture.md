---
title:            "The Big Picture"
slug:             the-big-picture
category:         templates
src:              /templates/the-big-picture
layout:           preview
type:             template
meta-title:       The Big Picture - Template Preview
migrated:         true
---

---
title:            "Landing Page"
slug:             landing-page
category:         themes
src:              /themes/landing-page
layout:           preview
type:             theme
meta-title:       Landing Page - Theme Preview
migrated:         true
---

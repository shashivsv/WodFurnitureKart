---
title:            "Resume"
slug:             resume
category:         themes
src:              /themes/resume
layout:           preview
type:             theme
meta-title:       Resume - Theme Preview
migrated:         true
---

---
title:            "Grayscale"
slug:             grayscale
category:         themes
src:              /themes/grayscale
layout:           preview
type:             theme
meta-title:       Grayscale - Theme Preview
migrated:         true
---

---
title:            "Simple Sidebar"
slug:             simple-sidebar
category:         templates
src:              /templates/simple-sidebar
layout:           preview
type:             template
meta-title:       Simple Sidebar - Template Preview
migrated:         true
---

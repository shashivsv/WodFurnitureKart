---
title:            "Freelancer"
slug:             freelancer
category:         themes
src:              /themes/freelancer
layout:           preview
type:             theme
meta-title:       Freelancer - Theme Preview
builder:          true
migrated:         true
---

---
title:            "Blog Post"
slug:             blog-post
category:         templates
src:              /templates/blog-post
layout:           preview
type:             template
meta-title:       Blog Post - Template Preview
migrated:         true
---

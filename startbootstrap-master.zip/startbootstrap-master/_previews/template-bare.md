---
title:            "Bare"
slug:             bare
category:         templates
src:              /templates/bare
layout:           preview
type:             template
meta-title:       Bare - Template Preview
migrated:         true
---

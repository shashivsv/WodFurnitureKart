---
title:            "SB Admin"
slug:             sb-admin
category:         templates
src:              /templates/sb-admin
layout:           preview
type:             template
meta-title:       SB Admin - Template Preview
migrated:         true
---

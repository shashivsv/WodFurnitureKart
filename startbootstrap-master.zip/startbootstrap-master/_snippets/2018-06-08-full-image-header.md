---
title:             "Bootstrap 4 Full Page Image Header"
slug:              full-image-header
src:               /snippets/full-image-header
description:	    "A Bootstrap 4 header with a full page background image and vertically centered content"
bump:			        "Full Page Image Header with Vertically Centered Content"
img-thumbnail:	    	  /assets/img/screenshots/snippets/full-image-header.jpg
img-desc:		      "A Bootstrap 4 starter layout with a full page image header and vertically centered content"
layout:		    	  overview-snippet
type:             snippet

rank:             12

dependencies:     
  - Bootstrap 4.3.1

updated: 2019-05-08

jsfiddle-id: "q4khv018"

meta-title:        "Bootstrap 4 Full Page Image Header with Vertically Centered Content"
meta-description:  "A Bootstrap 4 starter layout with a full page image header and vertically centered content - created by Start Bootstrap."
---

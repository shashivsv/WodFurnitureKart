---
title:             "Bootstrap 4 About and Team Section"
slug:              about-team
src:               /snippets/about-team
description:	    "A Bootstrap 4 example layout with an about section and team members"
bump:			        "About and Team Member Example Section Layout"
img-thumbnail:	    	  /assets/img/screenshots/snippets/about-team.jpg
img-desc:		      "A Bootstrap 4 example layout with an about section and team members"
layout:		    	  overview-snippet
type:             snippet

rank:             11

dependencies:     
  - Bootstrap 4.3.1

updated: 2019-05-08

jsfiddle-id: "2Lkm6e1j"

meta-title:        "Bootstrap 4 About Page and Team Member Example Section Layouts"
meta-description:  "A Bootstrap 4 example layout with an about section and team members - created by Start Bootstrap."

redirect_from:
  - /round-about/
  - /round-about.php/
  - /downloads/round-about.zip/
  - /template-overviews/round-about
---

---
title:             "Flexbox Sticky Footer"
slug:              sticky-footer-flexbox
src:               /snippets/sticky-footer-flexbox
description:	    "A sticky footer page layout using Bootstrap 4 flex utility classes"
bump:			        "A Sticky Footer Layout using Bootstrap 4 Flex Utility Classes"
img-thumbnail:	    	  /assets/img/screenshots/snippets/sticky-footer-flexbox.jpg
img-desc:		      "A Sticky Footer Layout Using Bootstrap 4 Utility Classes"
layout:		    	  overview-snippet
type:             snippet

rank:             2

dependencies:     
  - Bootstrap 4.3.1

jsfiddle-id: "out2g1mq"

meta-title:        "Bootstrap 4 Flexbox Sticky Footer"
meta-description:  "A flexbox sticky footer page layout using Bootstrap 4 flex utility classes"
---

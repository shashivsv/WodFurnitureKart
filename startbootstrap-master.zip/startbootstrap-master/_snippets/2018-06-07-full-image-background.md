---
title:             "Full Page Image HTML Background for Bootstrap"
slug:              full-image-background
src:               /snippets/full-image-background
description:	    "A Bootstrap 4 starter layout with a full page fixed background image and content cards"
bump:			        "Fixed on Scroll Full Page Image Background"
img-thumbnail:	    	  /assets/img/screenshots/snippets/full-image-background.jpg
img-desc:		      "A Bootstrap 4 starter layout with a full page fixed background image and content cards"
layout:		    	  overview-snippet
type:             snippet

rank:             14

dependencies:     
  - Bootstrap 4.3.1

updated: 2019-05-08

jsfiddle-id: "t7suLowj"

meta-title:        "Full Page Image HTML Background for Bootstrap"
meta-description:  "A Bootstrap 4 starter layout with a full page fixed on scrolling background image and content cards - created by Start Bootstrap."

redirect_from:
  - /full/
  - /full.php/
  - /downloads/full.zip/
  - /template-overviews/full
---

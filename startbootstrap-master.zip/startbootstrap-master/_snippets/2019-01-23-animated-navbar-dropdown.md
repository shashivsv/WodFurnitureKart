---
title:             "Dropdown Menu Animation for Bootstrap Navbar"
slug:              animated-navbar-dropdown
src:               /snippets/animated-navbar-dropdown
description:	    "CSS Only, simple and attractive animated dropdown menu for Bootstrap 4 navbars"
bump:			        "CSS Only Animations for Bootstrap 4 Navbar Dropdowns"
img-thumbnail:	    	  /assets/img/screenshots/snippets/animated-navbar-dropdowns.jpg
img-desc:		      "Bootstrap 4 Navbar Dropdown Menu Animation"
layout:		    	  overview-snippet
type:             snippet

rank:             1

dependencies:     
  - Bootstrap 4.3.1

jsfiddle-id: "o7ev9czn"

meta-title:        "Bootstrap 4 Navbar Dropdown Animations"
meta-description:  "An easy to use dropdown menu animation for the Bootstrap 4 navbar component"
---
